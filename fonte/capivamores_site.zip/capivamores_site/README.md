# Capivamores — Landing Page

Arquivos finais da landing page Capivamores.

## Como abrir localmente

1. Descompacte o arquivo `.zip`.
2. Abra a pasta `capivamores_site_final`.
3. Clique duas vezes no arquivo `index.html`.

O site foi preparado com caminhos relativos, então as imagens carregam direto da pasta `assets/`.

## Estrutura

- `index.html` — página principal
- `style.css` — estilos da landing page
- `script.js` — animações leves/interações
- `assets/` — imagens, capas, favicon e prévias internas

## Observações

- Os botões de compra apontam para a Amazon.
- O botão de contato abre e-mail para `contato@asesdaliteratura.com.br`.
- A fonte principal usa Google Fonts quando houver internet; offline, o navegador usa as fontes de sistema como fallback.
