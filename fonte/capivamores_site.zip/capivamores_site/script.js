const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.14 });

document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));

if (!prefersReduced) {
  document.querySelectorAll('[data-tilt]').forEach((card) => {
    card.addEventListener('pointermove', (event) => {
      const rect = card.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - 0.5;
      const y = (event.clientY - rect.top) / rect.height - 0.5;
      card.style.transform = `rotateX(${y * -5}deg) rotateY(${x * 7}deg)`;
    });
    card.addEventListener('pointerleave', () => {
      card.style.transform = 'rotateX(0deg) rotateY(0deg)';
    });
  });
}

const gallery = document.querySelector('.gallery');
document.querySelector('.gallery-btn.next')?.addEventListener('click', () => {
  gallery.scrollBy({ left: Math.round(gallery.clientWidth * 0.78), behavior: prefersReduced ? 'auto' : 'smooth' });
});
document.querySelector('.gallery-btn.prev')?.addEventListener('click', () => {
  gallery.scrollBy({ left: -Math.round(gallery.clientWidth * 0.78), behavior: prefersReduced ? 'auto' : 'smooth' });
});
